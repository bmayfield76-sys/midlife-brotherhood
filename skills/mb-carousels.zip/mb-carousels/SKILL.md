---
name: mb-carousels
description: Build Midlife Brotherhood Instagram listicle carousels, static PNGs by default or motion-graphics MP4s on request -- a cover slide with a numbered hook ("5 Things I Wish I Knew at 30," "7 Non-Negotiables About TRT," "10 Daily Habits of a Modern Stoic"), one slide per point (big red number, bold headline, a sentence or two), a closing CTA slide, plus a ready-to-paste caption and hashtags. Use whenever Billy asks for a "carousel," "listicle," "swipe post," "IG slides," a numbered "X things / X habits / X rules / X mistakes / X lessons" post, or wants a book/blog idea turned into a multi-slide post. Also the front door for motion / animated / video carousels of a listicle: it owns the copy and hands rendering to carousels-on-steroids with the Midlife Brotherhood motion kit. The multi-slide sibling of mb-quote-cards (use that one for single standalone quote cards). Always render static slides with the bundled make_carousel.py script (motion goes through carousels-on-steroids code, also never AI image generation) -- never Canva's AI generate-design or any other AI image generator -- because AI generation garbles exact text and breaks the numbering a listicle depends on.
---

# Midlife Brotherhood Carousels

Turns a topic into a full Instagram listicle carousel, end to end: cover
slide, one numbered slide per point, closing CTA slide, plus the caption and
hashtags to post it. Same brand look and same "render with code, not AI" rule
as mb-quote-cards.

## Why this renders slides with code, not AI generation

A listicle lives or dies on exact text and exact order -- "7" on the cover
has to mean seven slides that count 1 through 7, verbatim. AI design
generators (Canva's `generate-design` and friends) paraphrase headlines,
drop or reorder items, and eyeball number sizing. That was tried on the quote
cards and consistently produced rework. Every slide here goes through
`scripts/make_carousel.py` (Pillow), which is deterministic and repeatable.
Never swap in an AI image tool, even if asked to "just do it in Canva" -- if
Billy wants these in Canva, render them here first and upload the finished
PNGs.

## Workflow

### 1. Lock the title and the count

The title is the hook, and the number in it drives everything: a title of
"7 Non-Negotiables About TRT" means seven item slides. Billy usually brings
the title. If he brings a topic but no number, suggest 5, 7, or 10 (his
usual counts) based on how much real material the topic has -- don't pad a
thin topic to 10, and don't cram 12 good points into 7.

If he wants title ideas, pitch a few in his themes (nutrition, strength,
mindset, purpose, dating, rebuilding, evolutionary psychology) and let him
pick before anything else happens. Good hook shapes that work for him:
"X Things I Wish I Knew at 30," "X Non-Negotiables About ___," "X Daily
Habits of ___," "X Lies About ___," "X Mistakes Killing Your ___," "X Rules
for ___."

### 2. Source the items

Same source priority as the quote cards -- Billy's own material first, fresh
writing only to fill the gaps:

1. Any manuscript, blog post, or doc he just uploaded or pointed at.
2. Connected Google Drive / Notion / Dropbox for files matching his book
   titles (The Comeback Code, The Long Game, The Midlife Comeback Plan) or
   "blog" / "Midlife Brotherhood."
3. His live blog at midlifebrotherhood.com if the topic likely has a post.

Pull points that already fit the title. When you're short, write the
remaining ones fresh in his voice to complete the set. This matters:
**mark which items came from his books/blog and which you wrote fresh** when
you present the list, so he's reviewing his own words vs. new copy with eyes
open. Never pass off another author's quote (an epigraph he cited) as his.

### 3. Draft each item, then get sign-off before rendering

Every item slide has two parts:
- **Headline**: the punchy point itself. A few words to one short line. This
  is what someone remembers. Direct, Gen X, no-BS.
- **Body**: one or two sentences that make the point land -- the "why" or the
  "how." Keep it tight; this is a slide, not a paragraph. Two sentences is
  the ceiling before the text shrinks too small to read on a phone.

Keep headlines roughly parallel in shape across the set (all imperatives, or
all "X is Y" statements) so the carousel feels designed, not dumped.

Also draft the **CTA slide** (headline + one or two ask lines -- follow, DM a
keyword, link in bio) and the **caption + hashtags**.

Present the whole thing as text first: title, the numbered headline+body
list (sourced vs. fresh flagged), the CTA, and the caption. Get explicit
sign-off here. It's cheap to redo a line now and expensive to re-render a
nine-slide batch, so this gate is where the real editing happens.

### 3b. Pick the format: static or motion

After sign-off, ask once: **static** (PNG slides, minutes, the default) or **motion** (every
slide a looping MP4, one continuous scene, a real build per post)? Recommend motion only for
flagship posts: a topic that already performed as a static post or blog. If Billy picks motion,
skip steps 4-5 and follow `references/motion.md`. The approved copy, CTA and caption carry over
verbatim. If he already said "motion carousel" in the request, don't ask.

### 4. Render the carousel

Write the approved content to a JSON spec and run the script. The spec shape:

```json
{
  "title": "7 Non-Negotiables About TRT",
  "eyebrow": "MIDLIFE BROTHERHOOD",
  "contents": true,
  "items": [
    {"headline": "Get real labs first",
     "body": "Total T, free T, estradiol. No bloodwork, no needle."},
    {"headline": "It's a floor, not a shortcut",
     "body": "TRT fixes a deficiency. It doesn't replace the gym or the diet."}
  ],
  "cta": {
    "headline": "You In?",
    "body": ["Follow @midlifebrotherhood for the straight talk.",
             "DM 'PLAN' and let's build your comeback."]
  }
}
```

`contents: true` inserts a "what's inside" slide right after the cover -- a
numbered preview of every headline. It front-loads the payoff (people swipe to
reach a point they already saw), which lifts completion, and it's the one idea
worth borrowing from high-performing listicle carousels. Default it on unless
Billy wants a leaner set. Override the label with `contents_label` (defaults to
"THE LIST"). The number of `items` must match the number in the title. Then:

```bash
python3 scripts/make_carousel.py spec.json /tmp/carousel_out
```

This writes ordered PNGs: `slide_01_cover.png`, `slide_02.png` ... then
`slide_NN_cta.png`. They sort in swipe order, which is also the order they
must be uploaded to Instagram.

**Render the cover plus the first item slide and show those two to Billy
before running the whole batch.** The cover confirms the title layout and the
item slide confirms text sizing at a real length. Once he okays the look,
render the rest without asking per-slide.

Template defaults (Billy's approved look -- only change on explicit request):
- Canvas 1080x1350 (IG portrait 4:5), flat `#1A1A1A` background.
- Cover: brand eyebrow up top, big red count, white uppercase title, red
  rule, "SWIPE ->" cue, wolf icon bottom-right.
- Contents (optional, recommended): "THE LIST" eyebrow, every item headline
  numbered in red and left-aligned, "SWIPE ->" cue, wolf icon.
- Item slides: big red two-digit number, white bold headline, red rule, grey
  supporting text, "N / total" progress bottom-left, wolf icon bottom-right.
- CTA: centered wolf mark, brand eyebrow, white headline, red rule, grey ask.
- Colors: white headlines, grey (`#BCBCBC`) body, red (`#D7141E`) accents. The same red is used
  by the motion kit, so static and motion posts match in the feed.

The bundled `assets/mb_icon_gritty_master_900.png` is Billy's real wolf-in-
shield mark -- use it directly, don't regenerate or approximate it. For a
different aspect (square 1:1, Story 9:16), change `W, H` at the top of
`make_carousel.py` and re-render rather than retrofitting existing PNGs.

### 5. Package and deliver

Zip the slides in order and hand over the caption alongside:

```bash
cd /tmp/carousel_out && zip -j -q MB_Carousel_TRT.zip *.png
```

Deliver:
- The zip of ordered slides (tell him to upload in filename order).
- The **caption**: two or three lines in his voice that tee up the swipe, an
  optional line of value, and the CTA. End with a clean hashtag block (a mix
  of broad and niche tags -- midlife, men's health, the specific topic).

Present the zip and caption with the file-sharing tool so he can grab them.

## Adapting to other brands

Swap the brand constants (`BG`, `RED`, `WHITE`, `MUTED`, fonts) at the top of
`make_carousel.py` and swap the icon asset. `prep_icon()` assumes a light mark
on a dark background; invert its alpha logic for a dark-on-light icon.
