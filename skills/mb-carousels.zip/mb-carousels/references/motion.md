# Motion path: hand an approved listicle to Carousels on Steroids

Use this only when Billy picks **motion** at the format step. Static stays the default.
mb-carousels owns the copy (sourcing, sourced-vs-fresh flags, sign-off, caption). The
carousels-on-steroids skill owns the rendering. Don't edit that skill itself: its creator
ships updates, and everything Midlife Brotherhood lives here in `motion-kit/`.

## Prerequisites (check once per machine)
- `~/.claude/skills/carousels-on-steroids/` is installed. If not, tell Billy to run the kit's
  install prompt (the zip from Skool / Drive) and stop.
- `bash ~/.claude/skills/carousels-on-steroids/scripts/setup.sh` prints "All set".
- Running as root (cloud containers)? Chrome needs `--no-sandbox`: write a two-line wrapper
  script that execs the browser with that flag and point `CHROME=` at it. Never edit the kit for this.

## Build
1. `python3 ~/.claude/skills/carousels-on-steroids/scripts/new_carousel.py ~/carousels-on-steroids/motion/<short-name>`
2. `bash <this skill>/scripts/apply_motion_kit.sh ~/carousels-on-steroids/motion/<short-name>`
   This installs the brand: Poppins 800/700/500 (OFL), the wolf + shield cut from the official
   logo, the charcoal world with a red `#D7141E` CTA slide, the red pulse line that runs through
   every slide, the chrome (shield + MIDLIFE BROTHERHOOD top-left, counter bottom-left), and the
   Dating Rules build as the starting `00-project.js` / `03-slides.js`.
3. Read the carousels-on-steroids `SKILL.md` and `references/engine-api.md`, then edit:
   - `src/00-project.js`: title, `slides` and `counters` (one per slide; slide count = item count + 2).
   - `src/03-slides.js`: one object per slide, and `const SL = [...]` in order. Keep S1 (cover,
     swap the numeral and title) and the last slide (CTA, swap the copy). For each item slide, keep
     `ruleText(num, '', body, { lines: [...] })` for the type and **invent a new visual metaphor**
     for that point. Never reuse the Dating Rules visuals for a different post.
   - Leave `02-hero.js` and `04-world.js` alone unless Billy asks for a brand change.
4. `python3 build.py`, then QA per the carousels-on-steroids `references/qa.md`: contact sheet,
   seams, big moments at full size. Look at every image before showing Billy.
5. `node tools/capture.mjs video renders all` gives `slide-01.mp4 …` in posting order.

## Brand rules that carry over from the static template
- Red is `#D7141E` everywhere (static and motion). White headlines, grey `#B3B3B3` body.
- One CTA only, on the last slide. Copy is the approved copy, verbatim.
- Text is fully readable at frame 0 of every slide and settles back by the loop end.
- Loops are 8 s = 3 bars at 90 BPM. Big hits land on snares: `SN(1)`, `SN(3)`, `SN(5)`… (0.67, 2.0, 3.33 s).
- Music goes on in the Instagram app (one track across the post), never baked into the MP4s.
- Keep the top-right and bottom-right 72 px clear (Instagram's counter and sound icon).

## What each item slide needs (the part that can't be templated)
For each point: one visual metaphor tied to the line (the Dating Rules set used a scale, a stuck
dial-up terminal, a notification stack + falling key, a flipping card, a clock, a stamp bouncing
off a calendar, paths lighting up), one big moment on a snare, a second beat mid-loop, a typography
treatment no other slide uses, and a spike on the pulse line (`spikes: [[time, amp]]`). Budget the
time: a static carousel is minutes, a motion one is a real build.

## Deliver
The MP4s in order, the caption (same as static, with posting notes saying "upload the N MP4s in
order, add the song in Instagram"), and `carousel.html` for previewing.
