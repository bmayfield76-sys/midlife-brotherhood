#!/usr/bin/env bash
# Turns a fresh carousels-on-steroids project into a Midlife Brotherhood project.
# Usage: bash apply_motion_kit.sh <project_dir>
# Run AFTER: python3 ~/.claude/skills/carousels-on-steroids/scripts/new_carousel.py <project_dir>
set -e
KIT="$(cd "$(dirname "$0")/.." && pwd)"
P="${1:?usage: apply_motion_kit.sh <project_dir>}"
[ -f "$P/build.py" ] && [ -d "$P/src" ] || { echo "Not a carousels-on-steroids project: $P"; exit 1; }
cp "$KIT/motion-kit/src/02-hero.js" "$KIT/motion-kit/src/04-world.js" "$P/src/"
# starting point: the Dating Rules build (cover, 7 rule slides, red CTA). Replace copy + per-slide visuals.
cp "$KIT/examples/dating-rules-motion/00-project.js" "$KIT/examples/dating-rules-motion/03-slides.js" "$P/src/"
mkdir -p "$P/assets" && cp "$KIT/motion-kit/assets/"*.png "$P/assets/"
cp "$KIT/motion-kit/fonts/"* "$P/fonts/"
rm -f "$P/fonts/Anton.woff2" "$P/fonts/Anybody"*.woff2 "$P/fonts/OFL-anton.txt" "$P/fonts/OFL-anybody.txt"
python3 - "$P/build.py" <<'PY'
import re, sys, pathlib
p = pathlib.Path(sys.argv[1]); s = p.read_text()
s = re.sub(r'FONTS = \[.*?\]\n', 'FONTS = [("MBP8", "poppins-latin-800-normal.woff2"), ("MBP7", "poppins-latin-700-normal.woff2"), ("MBP5", "poppins-latin-500-normal.woff2"), ("EBMono", "MonoBold.woff2")]\n', s, count=1)
p.write_text(s)
PY
python3 "$P/build.py"
echo "Midlife Brotherhood kit applied to $P"
